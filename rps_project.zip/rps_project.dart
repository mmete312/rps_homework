import 'dart:io';
import 'dart:math';

enum Move { rock, paper, scissors }

void main() {
  print("Welcome to rock, paper, scissors game");
  var playerMove;
  var playerScore = 0;
  var aiScore = 0;
  while (true) {
    //getting user input
    stdout.write(
        "Select your move (r/p/s/q) : "); //r is for rock, p is for paper, s is for scissors, q is for quit
    final userInput = stdin.readLineSync();

    //selecting player move

    if (userInput == 'r') {
      playerMove = Move.rock;
    } else if (userInput == 'p') {
      playerMove = Move.paper;
    } else if (userInput == 's') {
      playerMove = Move.scissors;
    } else if (userInput == 'q') {
      print("Thanks for playing see you soon!");
      break;
    } else {
      print("Invalid input");
    }

    // select ai move
    final randomNumber = Random().nextInt(3); 
    final aiMove = Move.values[randomNumber];

    //showing player & ai move
    print("You played : $playerMove");
    print("Ai played : $aiMove");

    //game logic

    if (playerMove == Move.rock && aiMove == Move.scissors ||
        playerMove == Move.paper && aiMove == Move.rock ||
        playerMove == Move.scissors && aiMove == Move.paper) {
      print("You win !");
      playerScore++;
    } else if (playerMove == aiMove)
      print("Draw !");
    else {
      print("You lose !");
      aiScore++;
    }
    print("Current Score is Player :  $playerScore           Ai : $aiScore  ");
  }
}
